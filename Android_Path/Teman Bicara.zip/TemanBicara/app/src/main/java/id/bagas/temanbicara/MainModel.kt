package id.bagas.temanbicara

data class MainModel (
    val terapis: ArrayList<Terapis>
) {
//    data class Result (val id: Int, val title: String, val image: String)
    data class Terapis (
        val id: String,
        val name: String,
        val photo: String,
        val location: String,
        val rating: Float,
        val price: Int
    )
}
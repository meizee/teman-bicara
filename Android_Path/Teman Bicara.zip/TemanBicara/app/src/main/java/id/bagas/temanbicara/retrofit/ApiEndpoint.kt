package id.bagas.temanbicara.retrofit

import id.bagas.temanbicara.MainModel
import retrofit2.Call
import retrofit2.http.*

interface ApiEndpoint {

//    @GET("data.php")
//    fun data(): Call<MainModel>


    @GET("terapis/read")
    fun data(): Call<MainModel>
}
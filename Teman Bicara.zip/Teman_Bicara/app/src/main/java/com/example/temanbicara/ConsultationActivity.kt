package com.example.temanbicara

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.temanbicara.adapter.MentorAdapter
import com.example.temanbicara.adapter.RecycleMenuAdapter
import com.example.temanbicara.api.ApiService
import com.example.temanbicara.databinding.ActivityChatBinding
import com.example.temanbicara.databinding.ActivityConsultationBinding
import com.example.temanbicara.model.MentorModel
import com.example.temanbicara.model.RecycleMenuModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ConsultationActivity : AppCompatActivity() {

    private val TAG: String = "ConsultationActivity"

    private lateinit var auth: FirebaseAuth
    private lateinit var binding: ActivityConsultationBinding
    private lateinit var rvMenu: RecyclerView
    private val list = ArrayList<RecycleMenuModel>()

    private lateinit var mentorAdapter: MentorAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultation)

        supportActionBar!!.title = "Mentors"
        setupRecyclerView()
        getDataFromApi()

//        auth = Firebase.auth
//        val firebaseUser = auth.currentUser
//        if (firebaseUser == null) {
//            // Not signed in, launch the Login activity
//            startActivity(Intent(this, LoginActivity::class.java))
//            finish()
//            return
//        }

//        rvMenu = findViewById(R.id.rv_mentor_info)
//        rvMenu.setHasFixedSize(true)
//
//        list.addAll(listMenu)
//        showRecyclerList()
//
//        val buttonClick = findViewById<Button>(R.id.btn_home_consultation)
//        buttonClick.setOnClickListener {
//            val intent = Intent(this, ConsultationActivity::class.java)
//            startActivity(intent)
//        }
    }



//    private val listMenu: ArrayList<RecycleMenuModel>
//        get() {
//            val dataName = resources.getStringArray(R.array.data_name)
//            val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
//            val listUser= ArrayList<RecycleMenuModel>()
//            for (i in dataName.indices) {
//                val menu = RecycleMenuModel(dataName[i],dataPhoto.getResourceId(i, -1))
//                listUser.add(menu)
//            }
//            return listUser
//        }
//
//    private fun showRecyclerList() {
//        rvMenu.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true)
//        val listUserAdapter = RecycleMenuAdapter(list)
//        rvMenu.adapter = listUserAdapter
//        listUserAdapter.setOnItemClickCallback(object : RecycleMenuAdapter.OnItemClickCallback {
//            override fun onItemClicked(data: RecycleMenuModel) {
//                val intentToDetail = Intent(this@ConsultationActivity, ChatActivity::class.java)
//                intentToDetail.putExtra("DATA", data)
//                startActivity(intentToDetail)
//            }
//        })
//    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.bottom_nav_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_logout -> {
                signOut()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun signOut() {
        auth.signOut()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun setupRecyclerView(){
        mentorAdapter = MentorAdapter(arrayListOf(), object : MentorAdapter.OnAdapterListener {
            override fun onClick(result: MentorModel.Terapis) {
                startActivity(
                    Intent(this@ConsultationActivity, ChatActivity::class.java)
                        .putExtra("intent_title", result.name)
                        .putExtra("intent_image", result.photo)
                )
            }
        })
        binding.rvMentorInfo.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = mentorAdapter
        }
    }

    private fun getDataFromApi(){
        showLoading(true)
        ApiService.endpoint.data()
            .enqueue(object : Callback<MentorModel> {
                override fun onFailure(call: Call<MentorModel>, t: Throwable) {
                    printLog( t.toString() )
                    showLoading(false)
                }
                override fun onResponse(
                    call: Call<MentorModel>,
                    response: Response<MentorModel>
                ) {
                    showLoading(false)
                    if (response.isSuccessful) {
                        showResult( response.body()!! )
                    }
                }
            })
    }

    private fun printLog(message: String) {
        Log.d(TAG, message)
    }

    private fun showLoading(loading: Boolean) {
        when(loading) {
            true -> binding.progressBar.visibility = View.VISIBLE
            false ->  binding.progressBar.visibility = View.GONE
        }
    }

    private fun showResult(results: MentorModel) {
        for (result in results.terapis) printLog( "title: ${result.name}" )
        mentorAdapter.setData( results.terapis )
    }
}
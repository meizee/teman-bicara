package com.example.temanbicara.model

import android.os.Parcelable

data class RecycleMenuModel (
    val name: String,
    val photo: Int
    )
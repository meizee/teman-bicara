package com.example.temanbicara.adapter

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.example.temanbicara.R
import com.example.temanbicara.model.MentorModel
import kotlinx.android.synthetic.main.item_consultation.view.*
import kotlin.collections.ArrayList
//import kotlinx.android.synthetic.main.activity_main.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MentorAdapter (var results: ArrayList<MentorModel.Terapis>, val listener: OnAdapterListener):
    RecyclerView.Adapter<MentorAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ViewHolder (
        LayoutInflater.from( parent.context ).inflate( R.layout.item_consultation,
            parent, false)
    )

    override fun getItemCount() = results.size

//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//        val result = results[position]
//        holder.view.textView.text = result.name
//        Glide.with(holder.view)
//            .load(result.photo)
//            .placeholder(R.drawable.img_placeholder)
//            .error(R.drawable.img_placeholder)
//            .centerCrop()
//            .into(holder.view.imageView)
//        holder.view.setOnClickListener { listener.onClick( result ) }
//    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val result = results[position]
        holder.view.tv_name_doctor.text = result.name
        Glide.with(holder.view)
            .load(result.photo)
            .placeholder(R.drawable.img_placeholder)
            .error(R.drawable.img_placeholder)
            .centerCrop()
            .into(holder.view.img_mentor)
        holder.view.setOnClickListener { listener.onClick( result ) }
    }

    class ViewHolder(val view: View): RecyclerView.ViewHolder(view)

    fun setData(data: List<MentorModel.Terapis>){
        this.results.clear()
        this.results.addAll(data)
        notifyDataSetChanged()
    }

    interface OnAdapterListener {
        fun onClick(result: MentorModel.Terapis)
    }
}
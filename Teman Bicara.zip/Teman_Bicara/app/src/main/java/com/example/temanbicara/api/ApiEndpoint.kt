package com.example.temanbicara.api

import com.example.temanbicara.model.MentorModel
import retrofit2.Call
import retrofit2.http.*

interface ApiEndpoint {
    @GET("terapis/read")
    fun data(): Call<MentorModel>
}
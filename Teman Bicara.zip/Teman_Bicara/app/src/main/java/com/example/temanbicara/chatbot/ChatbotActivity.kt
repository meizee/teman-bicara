package com.example.temanbicara.chatbot

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.example.temanbicara.R
import com.example.temanbicara.ml.ChatbotModelNew
import com.example.temanbicara.ml.Classification
import org.tensorflow.lite.DataType
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.nio.ByteBuffer
import java.nio.charset.Charset

class ChatbotActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chatbot)

        // getting the object edit texts
        var ed1: EditText = findViewById(R.id.tf1)

        // getting the object of result textview
        val txtView: TextView = findViewById(R.id.textView)
        //var txtView2: TextView = findViewById(R.id.textView2);
        val buttonClick = findViewById<Button>(R.id.button_chatbot)

        // registering listener
        buttonClick.setOnClickListener{

            val model = ChatbotModelNew.newInstance(this)

//            public static Charset charset = Charset.forName("UTF-8");
//            public static CharsetEncoder encoder = charset.newEncoder();
//            public static CharsetDecoder decoder = charset.newDecoder();
//
//            public static ByteBuffer str_to_bb(String msg){
//                try{
//                    return encoder.encode(CharBuffer.wrap(msg));
//                }catch(Exception e){e.printStackTrace();}
//                return null;
//            }

            //val charset : Charset = ed1.text.toCharset()
            // getting values from edit text and converting to float
            val v1: ByteArray = ed1.text.toString().toByteArray()
            val v2: String = ed1.text.toString()
            //val v1: Float = ed1.text.toString().toFloat()
            //var v2: Float = ed2.text.toString().toFloat();
            //var v3: Float = ed3.text.toString().toFloat();
            //var v4: Float = ed4.text.toString().toFloat();

            /*************************ML MODEL CODE STARTS HERE******************/

            // creating byte buffer which will act as input for model
            val byte_buffer: ByteBuffer = ByteBuffer.allocateDirect(1 * 195)
            //byte_buffer.putFloat(v1)
            byte_buffer.put(v1)
            //byte_buffer.putFloat(v2)
            //byte_buffer.putFloat(v3)
            //byte_buffer.putFloat(v4)

            // Creates inputs for reference.
            val inputFeature0 = TensorBuffer.createDynamic(DataType.STRING)
            //val inputFeature0 = TensorBuffer.createFixedSize(intArrayOf(1, 195), DataType.STRING)
            inputFeature0.loadBuffer(byte_buffer)

            // Runs model inference and gets result.
            val outputs = model.process(inputFeature0)
            val outputFeature0 = outputs.outputFeature0AsTensorBuffer.toString()

            // setting the result to the output textview
            txtView.setText(outputFeature0)
            //txtView2.setText(outputFeature0.toString())
            //txtView2.setText(outputFeature0[1].toString())
            //                        " ,H2 =" + outputFeature0[1].toString() +
//                        " ,H3" +  outputFeature0[2].toString() +
//                        " ,H4" +  outputFeature0[3].toString() +
//                        " ,H5" +  outputFeature0[4].toString() +
//                        " ,H6" +  outputFeature0[5].toString() +
//                        " ,H7" +  outputFeature0[6].toString() +
//                        " ,H8" +  outputFeature0[7].toString() +
//                        " ,H9" +  outputFeature0[8].toString() +
//                        " ,H10" +  outputFeature0[9].toString() +
//                        " ,H11" +  outputFeature0[10].toString() +
//                        " ,H12" +  outputFeature0[11].toString() +
//                        " ,H13" +  outputFeature0[12].toString() +
//                        " ,H14" +  outputFeature0[13].toString() +
//                        " ,H15" +  outputFeature0[14].toString() +
//                        " ,H16" +  outputFeature0[15].toString()

            // Releases model resources if no longer used.
            model.close()
        }
    }
}
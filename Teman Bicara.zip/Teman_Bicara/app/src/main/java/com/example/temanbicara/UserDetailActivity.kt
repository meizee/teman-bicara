package com.example.temanbicara

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class UserDetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_detail)
    }
}
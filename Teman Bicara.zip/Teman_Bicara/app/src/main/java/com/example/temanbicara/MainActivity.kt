package com.example.temanbicara

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.temanbicara.adapter.RecycleMenuAdapter
import com.example.temanbicara.chatbot.ChatbotActivity
import com.example.temanbicara.databinding.ActivityMainBinding
import com.example.temanbicara.model.RecycleMenuModel
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var activityMainBinding: ActivityMainBinding
    private lateinit var rvMenu: RecyclerView
    private val list = ArrayList<RecycleMenuModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val navView: BottomNavigationView = findViewById(R.id.nav_view)

//        val navController = findNavController(R.id.nav_host_fragment)
//        // Passing each menu ID as a set of Ids because each
//        // menu should be considered as top level destinations.
//        val appBarConfiguration = AppBarConfiguration.Builder(
//            R.id.navigation_main, R.id.nav_guide, R.id.nav_mail, R.id.nav_journal
//        ).build()
//        setupActionBarWithNavController(navController, appBarConfiguration)
//        navView.setupWithNavController(navController)

        rvMenu = findViewById(R.id.rv_menu_icon)
        rvMenu.setHasFixedSize(true)

        list.addAll(listMenu)
        showRecyclerList()

        val buttonClick = findViewById<Button>(R.id.btn_home_chatbot)
        buttonClick.setOnClickListener {
            val intent = Intent(this, ChatbotActivity::class.java)
            startActivity(intent)
        }

        val buttonClick_2 = findViewById<Button>(R.id.btn_home_consultation)
        buttonClick_2.setOnClickListener {
            val intent = Intent(this, ConsultationActivity::class.java)
            startActivity(intent)
        }
        val imgView = findViewById<ImageView>(R.id.imageview_menu_more)
        //val layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true)
        //activityMainBinding.rvMenu.layoutManager = layoutManager
    }

    private val listMenu: ArrayList<RecycleMenuModel>
        get() {
            val dataName = resources.getStringArray(R.array.data_name)
            val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
            val listUser= ArrayList<RecycleMenuModel>()
            for (i in dataName.indices) {
                val menu = RecycleMenuModel(dataName[i],dataPhoto.getResourceId(i, -1))
                listUser.add(menu)
            }
            return listUser
        }

    private fun showRecyclerList() {
        rvMenu.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true)
        val listUserAdapter = RecycleMenuAdapter(list)
        rvMenu.adapter = listUserAdapter
        listUserAdapter.setOnItemClickCallback(object : RecycleMenuAdapter.OnItemClickCallback {
            override fun onItemClicked(data: RecycleMenuModel) {
                val intentToDetail = Intent(this@MainActivity, ChatActivity::class.java)
                startActivity(intentToDetail)
            }
        })
    }

//    override fun onCreateOptionsMenu(menu: Menu): Boolean {
//        val inflater = menuInflater
//        inflater.inflate(R.menu.bottom_nav_menu, menu)
//        return true
//    }

//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        return when (item.itemId) {
////            R.id.nav_home -> {
////                startActivity(
////                    Intent(this@MainActivity, ChatActivity::class.java)
////            }
//            R.id.nav_guide -> {
//                startActivity(Intent(this@MainActivity, ChatActivity::class.java))
//            }
//            R.id.nav_mail -> {
//                startActivity(
//                    Intent(this@MainActivity, ChatActivity::class.java)
//            }
//            R.id.nav_journal -> {
//                startActivity(
//                    Intent(this@MainActivity, ScheduleActivity::class.java)
//            }
//            else -> super.onOptionsItemSelected(item)
//        }
//    }





//    override fun onSupportNavigateUp(): Boolean {
//        val navController = findNavController(androidx.navigation.ui.R.id.nav_host_fragment)
//        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
//    }
}
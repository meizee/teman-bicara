package com.example.temanbicara.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.temanbicara.R
import com.example.temanbicara.model.RecycleMenuModel
import java.util.*

class RecycleMenuAdapter (private val listMenu: ArrayList<RecycleMenuModel>) : RecyclerView.Adapter<RecycleMenuAdapter.ListViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): RecycleMenuAdapter.ListViewHolder {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.item_home_menu, parent, false)
        return ListViewHolder(view)
    }

    //To change body of created functions use File | Settings | File Templates.
    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val (name, photo) = listMenu[position]
        holder.tvName.text = name
        holder.imgPhoto.setImageResource(photo)
        holder.itemView.setOnClickListener {
            onItemClickCallback.onItemClicked(listMenu[holder.adapterPosition])
        }
    }

    //To change body of created functions use File | Settings | File Templates.
    override fun getItemCount(): Int = listMenu.size

    class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imgPhoto: ImageView = itemView.findViewById(R.id.img_item_photo)
        var tvName: TextView = itemView.findViewById(R.id.tv_item_name)
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: RecycleMenuModel)
    }
}